def main(a,b):
    print("this is a test script")
    return 200

